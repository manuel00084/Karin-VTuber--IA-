﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FrameInfoPlugin
{
    public partial class FrameInfoDialog : Form
    {
        public FrameInfoDialog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// OK
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void okButton_Click(object sender, EventArgs e)
        {
            Hide();
        }

        /// <summary>
        /// テキスト
        /// </summary>
        public string FrameInfoText
        {
            get { return infoTextBox.Text; }
            set { infoTextBox.Text = value; }
        }

    }
}
