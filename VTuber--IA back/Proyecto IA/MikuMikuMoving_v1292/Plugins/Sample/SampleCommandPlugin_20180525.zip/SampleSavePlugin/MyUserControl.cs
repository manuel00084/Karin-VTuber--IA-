﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SampleSavePlugin
{
    public partial class MyUserControl : UserControl
    {
        public MyUserControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 保存テキスト
        /// </summary>
        public string Text
        {
            get { return saveTextBox.Text; }
            set { saveTextBox.Text = value; }
        }
    }
}
