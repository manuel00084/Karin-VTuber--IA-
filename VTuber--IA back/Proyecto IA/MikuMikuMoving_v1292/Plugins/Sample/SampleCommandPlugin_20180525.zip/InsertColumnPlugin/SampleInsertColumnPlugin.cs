﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using MikuMikuPlugin;
using DxMath;

namespace InsertColumnPlugin
{
    public class SampleInsertColumnPlugin : ICommandPlugin
    {
        /// <summary>
        /// このプラグインのGUID
        /// </summary>
        public Guid GUID
        {
            get { return new Guid("D9B12D4E-AF2D-4970-92FC-87B34DA80DEF"); }
        }

        /// <summary>
        /// メインフォーム
        /// MikuMikuMoving側から与えられます。
        /// ダイアログ表示やメッセージ表示に使用してください。
        /// </summary>
        public IWin32Window ApplicationForm { get; set; }

        /// <summary>
        /// シーンオブジェクト
        /// MikuMikuMoving側から与えられます。
        /// MikuMikuMovingのモデルやアクセサリといったオブジェクトにアクセスできます。
        /// </summary>
        public Scene Scene { get; set; }

        /// <summary>
        /// プラグインの名前や作者名、プラグインの説明
        /// </summary>
        public string Description
        {
            get { return "Sample InsertColumn Plugin by Mogg"; }
        }

        /// <summary>
        /// ボタンに表示するアイコン画像(32x32)
        /// nullだとデフォルト画像が表示されます。
        /// </summary>
        public Image Image
        {
            get { return null; }
        }

        /// <summary>
        /// 中コマンドバーに表示するアイコン画像(20x20)
        /// nullだとデフォルト画像が表示されます。
        /// </summary>
        public Image SmallImage
        {
            get { return null; }
        }

        /// <summary>
        /// ボタンに表示するテキスト
        /// 日本語環境で表示されるテキストです。改行する場合は Environment.NewLineを使用してください。
        /// </summary>
        public string Text
        {
            get { return "列挿入" + Environment.NewLine + "プラグイン"; }
        }

        /// <summary>
        /// ボタンに表示する英語テキスト
        /// 日本以外の環境で表示されるテキストです。
        /// </summary>
        public string EnglishText
        {
            get { return "InsertColumn" + Environment.NewLine + "Plugin"; }
        }

        /// <summary>
        /// 実行
        /// ここにボタンが押されたときの処理を記述します。
        /// </summary>
        public void Run(CommandArgs e)
        {
            //現マーカー位置で挿入
            long frameposition = Scene.MarkerPosition;

            //モデル
            foreach (Model model in Scene.Models)
                model.InsertColumn(frameposition, EditColumnType.Bone | EditColumnType.Morph | EditColumnType.Property);

            //アクセサリ
            foreach (Accessory accessory in Scene.Accessories)
                accessory.InsertColumn(frameposition, EditColumnType.Bone | EditColumnType.Property);

            //エフェクト
            foreach (Effect effect in Scene.Effects)
                effect.InsertColumn(frameposition, EditColumnType.Bone | EditColumnType.Property);

            //カメラ
            foreach (Camera camera in Scene.Cameras)
                camera.InsertColumn(frameposition, EditColumnType.Bone | EditColumnType.Property);

            //ライト
            foreach (Light light in Scene.Lights)
                light.InsertColumn(frameposition, EditColumnType.Bone | EditColumnType.Property);

        }

        /// <summary>
        /// プラグイン破棄処理
        /// もし解放しないといけないオブジェクトがある場合は、ここで解放してください。
        /// </summary>
        public void Dispose()
        {

        }
    }
}
