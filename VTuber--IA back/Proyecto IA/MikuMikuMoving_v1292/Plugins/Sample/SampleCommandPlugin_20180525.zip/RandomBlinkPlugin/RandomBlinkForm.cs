﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RandomBlinkPlugin
{
    public partial class RandomBlinkForm : Form
    {
        public RandomBlinkForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// OKボタン
        /// </summary>
        private void okButton_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.OK;
            Hide();
        }

        /// <summary>
        /// Cancelボタン
        /// </summary>
        private void cancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            Hide();
        }

        /// <summary>
        /// 開始フレーム
        /// </summary>
        public long StartFrame
        {
            get { return (long)startUpDown.Value; }
        }

        /// <summary>
        /// 終了フレーム
        /// </summary>
        public long EndFrame
        {
            get { return (long)endUpDown.Value; }
        }
    }
}
