﻿namespace RandomBlinkPlugin
{
    partial class RandomBlinkForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RandomBlinkForm));
            this.startUpDown = new System.Windows.Forms.NumericUpDown();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.endUpDown = new System.Windows.Forms.NumericUpDown();
            this.hyphonLabel = new System.Windows.Forms.Label();
            this.startLabel = new System.Windows.Forms.Label();
            this.endLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.startUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.endUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // startUpDown
            // 
            resources.ApplyResources(this.startUpDown, "startUpDown");
            this.startUpDown.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.startUpDown.Name = "startUpDown";
            // 
            // okButton
            // 
            resources.ApplyResources(this.okButton, "okButton");
            this.okButton.Name = "okButton";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            resources.ApplyResources(this.cancelButton, "cancelButton");
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // endUpDown
            // 
            resources.ApplyResources(this.endUpDown, "endUpDown");
            this.endUpDown.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.endUpDown.Name = "endUpDown";
            // 
            // hyphonLabel
            // 
            resources.ApplyResources(this.hyphonLabel, "hyphonLabel");
            this.hyphonLabel.Name = "hyphonLabel";
            // 
            // startLabel
            // 
            resources.ApplyResources(this.startLabel, "startLabel");
            this.startLabel.Name = "startLabel";
            // 
            // endLabel
            // 
            resources.ApplyResources(this.endLabel, "endLabel");
            this.endLabel.Name = "endLabel";
            // 
            // RandomBlinkForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.endLabel);
            this.Controls.Add(this.startLabel);
            this.Controls.Add(this.hyphonLabel);
            this.Controls.Add(this.endUpDown);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.startUpDown);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RandomBlinkForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            ((System.ComponentModel.ISupportInitialize)(this.startUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.endUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown startUpDown;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.NumericUpDown endUpDown;
        private System.Windows.Forms.Label hyphonLabel;
        private System.Windows.Forms.Label startLabel;
        private System.Windows.Forms.Label endLabel;
    }
}