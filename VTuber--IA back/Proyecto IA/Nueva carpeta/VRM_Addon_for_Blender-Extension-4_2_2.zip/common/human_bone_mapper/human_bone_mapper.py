# SPDX-License-Identifier: MIT OR GPL-3.0-or-later
import re
from collections.abc import Mapping
from functools import cache
from typing import Final, Optional

from bpy.types import Armature, Bone, Object

from ..char import FULLWIDTH_ASCII_TO_ASCII_MAP
from ..logger import get_logger
from ..vrm1.human_bone import HumanBoneSpecification, HumanBoneSpecifications
from . import (
    biped_mapping,
    cats_blender_plugin_fix_model_mapping,
    microsoft_rocketbox_mapping,
    mixamo_mapping,
    mmd_mapping,
    mpfb_mapping,
    ready_player_me_mapping,
    rigify_meta_rig_mapping,
    unreal_mapping,
    vrm_addon_mapping,
    vroid_mapping,
)
from .structure_based_mapping import create_structure_based_mapping

BONE_NAME_LOWER_TO_UPPER_REGEX_SUB: Final = (re.compile(r"([a-z])([A-Z])"), r"\1.\2")
BONE_NAME_DIGIT_REGEX_SUB: Final = (re.compile(r"(\d+)"), r".\1.")
BONE_NAME_COMPONENT_SPLIT_REGEX: Final = re.compile(r"[-._: (){}[\]<>]+")

_logger = get_logger(__name__)


@cache
def _canonicalize_bone_name(bone_name: str) -> str:
    bone_name = "".join(FULLWIDTH_ASCII_TO_ASCII_MAP.get(c, c) for c in bone_name)
    bone_name = re.sub(*BONE_NAME_LOWER_TO_UPPER_REGEX_SUB, bone_name)
    bone_name = bone_name.lower()
    bone_name = "".join(" " if c.isspace() else c for c in bone_name)
    bone_name = re.sub(*BONE_NAME_DIGIT_REGEX_SUB, bone_name).strip(".")
    bone_name_components = re.split(BONE_NAME_COMPONENT_SPLIT_REGEX, bone_name)
    for patterns, replacement in {
        ("l", "左"): "left",
        ("r", "右"): "right",
    }.items():
        bone_name_components = [
            replacement if bone_name_component in patterns else bone_name_component
            for bone_name_component in bone_name_components
        ]
    return ".".join(bone_name_components)


def _match_bone_name(bone_name1: str, bone_name2: str) -> bool:
    return _canonicalize_bone_name(bone_name1) == _canonicalize_bone_name(bone_name2)


def _match_count(
    armature: Armature, mapping: Mapping[str, HumanBoneSpecification]
) -> int:
    count = 0

    mapping = {
        bpy_name: specification
        for bpy_name, specification in mapping.items()
        if any(_match_bone_name(bpy_name, bone.name) for bone in armature.bones)
    }

    # Validate bone ordering
    for bpy_name, specification in mapping.items():
        bone = next(
            (bone for bone in armature.bones if _match_bone_name(bpy_name, bone.name)),
            None,
        )
        if not bone:
            continue

        parent_specification: Optional[HumanBoneSpecification] = None
        search_parent_specification = specification.parent
        while search_parent_specification:
            if search_parent_specification in mapping.values():
                parent_specification = search_parent_specification
                break
            search_parent_specification = search_parent_specification.parent

        found = False
        bone: Optional[Bone] = bone.parent
        while bone:
            search_specification = next(
                (
                    search_specification
                    for bpy_name, search_specification in mapping.items()
                    if _match_bone_name(bpy_name, bone.name)
                ),
                None,
            )
            if search_specification:
                found = search_specification == parent_specification
                break
            bone = bone.parent

        if found or not parent_specification:
            count += 1
            continue

    return count


def _match_counts(
    armature: object, mapping: Mapping[str, HumanBoneSpecification]
) -> tuple[int, int]:
    if not isinstance(armature, Armature):
        message = f"{type(armature)} is not an Armature"
        raise TypeError(message)
    required_mapping = {
        bpy_name: required_specification
        for bpy_name, required_specification in mapping.items()
        if required_specification.requirement
    }
    return (_match_count(armature, required_mapping), _match_count(armature, mapping))


def _sorted_required_first(
    armature: Armature,
    mapping: Mapping[str, HumanBoneSpecification],
) -> dict[str, HumanBoneSpecification]:
    bpy_bone_name_mapping: dict[str, HumanBoneSpecification] = {
        bpy_bone_name: specification
        for original_bone_name, specification in mapping.items()
        if (
            bpy_bone_name := next(
                (
                    bone.name
                    for bone in armature.bones
                    if _match_bone_name(original_bone_name, bone.name)
                ),
                None,
            )
        )
    }
    sorted_mapping: dict[str, HumanBoneSpecification] = {}
    sorted_mapping.update(
        {
            bpy_name: specification
            for bpy_name, specification in bpy_bone_name_mapping.items()
            if specification.requirement
        }
    )
    sorted_mapping.update(
        {
            bpy_name: specification
            for bpy_name, specification in bpy_bone_name_mapping.items()
            if not specification.requirement
        }
    )
    return sorted_mapping


def create_human_bone_mapping(
    armature: Object,
) -> dict[str, HumanBoneSpecification]:
    armature_data = armature.data
    if not isinstance(armature_data, Armature):
        raise TypeError
    ((required_count, _all_count), name, mapping) = sorted(
        (_match_counts(armature_data, mapping), name, mapping)
        for name, mapping in (
            mmd_mapping.create_config(armature),
            biped_mapping.create_config(armature),
            mixamo_mapping.CONFIG,
            mpfb_mapping.CONFIG_DEFAULT,
            mpfb_mapping.CONFIG_GAME_ENGINE,
            unreal_mapping.CONFIG,
            ready_player_me_mapping.CONFIG,
            cats_blender_plugin_fix_model_mapping.CONFIG,
            microsoft_rocketbox_mapping.CONFIG_BIP01,
            microsoft_rocketbox_mapping.CONFIG_BIP02,
            rigify_meta_rig_mapping.CONFIG,
            vroid_mapping.CONFIG,
            vroid_mapping.CONFIG_SYMMETRICAL,
            vrm_addon_mapping.CONFIG_VRM1,
            vrm_addon_mapping.CONFIG_VRM0,
        )
    )[-1]
    result = {}
    wanted_required_count = sum(
        1 for spec in HumanBoneSpecifications.all_human_bones if spec.requirement
    )
    if required_count < wanted_required_count:
        structure_based_mapping = create_structure_based_mapping(armature)
        structure_base_mapping_required_count = sum(
            1 for spec in structure_based_mapping.values() if spec.requirement
        )
        if required_count < structure_base_mapping_required_count:
            mapping = structure_based_mapping
            name = "Structure Based Auto Detected"
            required_count = structure_base_mapping_required_count
    if required_count:
        _logger.debug('Treat as "%s" bone mappings', name)
        result = _sorted_required_first(armature_data, mapping)
    _canonicalize_bone_name.cache_clear()
    return result
