"""Twitch Keys — Actualizar Client ID y Client Secret de Twitch."""
import customtkinter as ctk
import requests

api = None


def on_load(_api):
    global api
    api = _api
    api.log("[Twitch Keys] Plugin cargado.")
    return True


def on_unload():
    api.log("[Twitch Keys] Plugin descargado.")


def on_ui_tab(parent):
    BG = "#1a1a2e"
    CARD = "#16213e"
    PURPLE = "#9146FF"
    GREEN = "#059669"
    RED = "#dc2626"
    TEXT = "#e2e8f0"
    TEXT_DIM = "#94a3b8"

    frame = ctk.CTkFrame(parent, fg_color="transparent")
    frame.grid(row=0, column=0, sticky="nsew")
    parent.grid_rowconfigure(0, weight=1)
    parent.grid_columnconfigure(0, weight=1)

    ctk.CTkLabel(frame, text="Twitch Client Keys",
        font=("Segoe UI", 22, "bold"), text_color=PURPLE
    ).pack(anchor="w", padx=20, pady=(20, 4))

    ctk.CTkLabel(frame,
        text="Actualiza el Client ID y Client Secret de tu app en Twitch.",
        font=("Segoe UI", 14), text_color=TEXT_DIM
    ).pack(anchor="w", padx=20, pady=(0, 16))

    card = ctk.CTkFrame(frame, fg_color=CARD, corner_radius=10)
    card.pack(fill="x", padx=16, pady=(0, 12))

    ctk.CTkLabel(card, text="Client ID",
        font=("Segoe UI", 14, "bold"), text_color=TEXT
    ).pack(anchor="w", padx=16, pady=(14, 4))

    cid_entry = ctk.CTkEntry(card, placeholder_text="4t7kth7bzynj...",
        font=("Consolas", 14), fg_color=BG, text_color=TEXT,
        border_color="#334155", height=38)
    cid_entry.pack(fill="x", padx=16, pady=(0, 10))

    ctk.CTkLabel(card, text="Client Secret",
        font=("Segoe UI", 14, "bold"), text_color=TEXT
    ).pack(anchor="w", padx=16, pady=(6, 4))

    csec_entry = ctk.CTkEntry(card, placeholder_text="Nuevo secret...",
        font=("Consolas", 14), fg_color=BG, text_color=TEXT,
        border_color="#334155", height=38, show="*")
    csec_entry.pack(fill="x", padx=16, pady=(0, 10))

    def toggle_show():
        c = csec_entry.cget("show")
        csec_entry.configure(show="" if c == "*" else "*")

    status_label = ctk.CTkLabel(card, text="", font=("Segoe UI", 13), text_color=TEXT_DIM)
    status_label.pack(anchor="w", padx=16, pady=(4, 6))

    from src.core.secrets_manager import _load_secrets
    secrets = _load_secrets()
    old_id = secrets.get("TWITCH_CLIENT_ID", "")
    old_secret = secrets.get("TWITCH_CLIENT_SECRET", "")
    if old_id:
        cid_entry.insert(0, old_id)
    if old_secret:
        csec_entry.insert(0, old_secret)

    btn_frame = ctk.CTkFrame(card, fg_color="transparent")
    btn_frame.pack(fill="x", padx=16, pady=(6, 14))
    btn_frame.grid_columnconfigure((0, 1, 2), weight=1)

    def guardar():
        from src.core.secrets_manager import set_secret
        cid = cid_entry.get().strip()
        csec = csec_entry.get().strip()
        if not cid and not csec:
            status_label.configure(text="Ingresa al menos un valor.", text_color=RED)
            return
        if cid:
            set_secret("TWITCH_CLIENT_ID", cid)
        if csec:
            set_secret("TWITCH_CLIENT_SECRET", csec)
        show_id = cid if cid else old_id
        preview = show_id[:8] + "..." + show_id[-4:] if len(show_id) > 12 else show_id
        status_label.configure(text="Guardado: " + preview, text_color=GREEN)
        api.log("[Twitch Keys] Keys actualizadas en secrets.enc")

    def probar():
        cid = cid_entry.get().strip()
        csec = csec_entry.get().strip()
        if not cid or not csec:
            status_label.configure(text="Ingresa Client ID y Secret para probar.", text_color=RED)
            return
        status_label.configure(text="Probando...", text_color=TEXT_DIM)
        try:
            r = requests.post("https://id.twitch.tv/oauth2/token", data={
                "client_id": cid, "client_secret": csec,
                "grant_type": "client_credentials"
            }, timeout=10)
            data = r.json()
            if "access_token" in data:
                status_label.configure(text="Credenciales validas!", text_color=GREEN)
                api.log("[Twitch Keys] Credenciales validas")
            else:
                msg = data.get("message", str(data))
                status_label.configure(text="Error: " + msg, text_color=RED)
                api.log("[Twitch Keys] Error: " + msg)
        except Exception as e:
            status_label.configure(text="Error de red: " + str(e), text_color=RED)

    ctk.CTkButton(btn_frame, text="Mostrar", fg_color="#334155", text_color=TEXT,
        hover_color="#475569", height=34, font=("Segoe UI", 13),
        corner_radius=8,
        command=toggle_show).grid(row=0, column=0, padx=(0, 4), sticky="ew")

    ctk.CTkButton(btn_frame, text="Guardar", fg_color=GREEN, text_color="#fff",
        hover_color="#047857", height=34, font=("Segoe UI", 13, "bold"),
        corner_radius=8,
        command=guardar).grid(row=0, column=1, padx=2, sticky="ew")

    ctk.CTkButton(btn_frame, text="Probar", fg_color=PURPLE, text_color="#fff",
        hover_color="#772CE8", height=34, font=("Segoe UI", 13, "bold"),
        corner_radius=8,
        command=probar).grid(row=0, column=2, padx=(4, 0), sticky="ew")

    link = ctk.CTkLabel(card, text="dev.twitch.tv/console/apps",
        font=("Segoe UI", 12), text_color="#818cf8", cursor="hand2")
    link.pack(anchor="w", padx=16, pady=(0, 10))
    link.bind("<Button-1>", lambda e: __import__("webbrowser").open("https://dev.twitch.tv/console/apps"))

    return frame
